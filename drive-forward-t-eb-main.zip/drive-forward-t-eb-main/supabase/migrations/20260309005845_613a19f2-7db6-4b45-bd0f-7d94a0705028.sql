-- Create a new public storage bucket for vehicle images
INSERT INTO storage.buckets (id, name, public) 
VALUES ('vehicle-images', 'vehicle-images', true)
ON CONFLICT (id) DO NOTHING;

-- Policy to allow anyone to read images
CREATE POLICY "Anyone can view vehicle images" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'vehicle-images');

-- Policy to allow admins to insert images
CREATE POLICY "Admins can upload vehicle images" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'vehicle-images' AND public.is_admin(auth.uid()));

-- Policy to allow admins to update images
CREATE POLICY "Admins can update vehicle images" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'vehicle-images' AND public.is_admin(auth.uid()));

-- Policy to allow admins to delete images
CREATE POLICY "Admins can delete vehicle images" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'vehicle-images' AND public.is_admin(auth.uid()));