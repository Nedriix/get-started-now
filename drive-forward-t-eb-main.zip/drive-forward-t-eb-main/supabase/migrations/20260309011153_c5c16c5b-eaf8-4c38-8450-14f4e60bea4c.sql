-- Remove the check constraint
ALTER TABLE vehicles DROP CONSTRAINT IF EXISTS vehicles_category_check;

-- Update categories to Czech
UPDATE vehicles SET category = 'Osobní' WHERE category = 'car';
UPDATE vehicles SET category = 'Motocykly' WHERE category = 'moto';
UPDATE vehicles SET category = 'Nákladní' WHERE category = 'truck';