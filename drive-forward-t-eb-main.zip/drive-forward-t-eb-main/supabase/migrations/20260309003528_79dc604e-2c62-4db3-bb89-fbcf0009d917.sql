
-- Fix RLS policies: recreate all as PERMISSIVE (not RESTRICTIVE)

-- NEWS
DROP POLICY IF EXISTS "Admins can delete news" ON public.news;
DROP POLICY IF EXISTS "Admins can insert news" ON public.news;
DROP POLICY IF EXISTS "Admins can update news" ON public.news;
DROP POLICY IF EXISTS "Anyone can read active news" ON public.news;

CREATE POLICY "Anyone can read news" ON public.news FOR SELECT USING (true);
CREATE POLICY "Admins can insert news" ON public.news FOR INSERT WITH CHECK (is_admin(auth.uid()));
CREATE POLICY "Admins can update news" ON public.news FOR UPDATE USING (is_admin(auth.uid()));
CREATE POLICY "Admins can delete news" ON public.news FOR DELETE USING (is_admin(auth.uid()));

-- PRICING CATEGORIES
DROP POLICY IF EXISTS "Admins can delete pricing_categories" ON public.pricing_categories;
DROP POLICY IF EXISTS "Admins can insert pricing_categories" ON public.pricing_categories;
DROP POLICY IF EXISTS "Admins can update pricing_categories" ON public.pricing_categories;
DROP POLICY IF EXISTS "Anyone can read pricing_categories" ON public.pricing_categories;

CREATE POLICY "Anyone can read pricing_categories" ON public.pricing_categories FOR SELECT USING (true);
CREATE POLICY "Admins can insert pricing_categories" ON public.pricing_categories FOR INSERT WITH CHECK (is_admin(auth.uid()));
CREATE POLICY "Admins can update pricing_categories" ON public.pricing_categories FOR UPDATE USING (is_admin(auth.uid()));
CREATE POLICY "Admins can delete pricing_categories" ON public.pricing_categories FOR DELETE USING (is_admin(auth.uid()));

-- PRICING ITEMS
DROP POLICY IF EXISTS "Admins can delete pricing_items" ON public.pricing_items;
DROP POLICY IF EXISTS "Admins can insert pricing_items" ON public.pricing_items;
DROP POLICY IF EXISTS "Admins can update pricing_items" ON public.pricing_items;
DROP POLICY IF EXISTS "Anyone can read pricing_items" ON public.pricing_items;

CREATE POLICY "Anyone can read pricing_items" ON public.pricing_items FOR SELECT USING (true);
CREATE POLICY "Admins can insert pricing_items" ON public.pricing_items FOR INSERT WITH CHECK (is_admin(auth.uid()));
CREATE POLICY "Admins can update pricing_items" ON public.pricing_items FOR UPDATE USING (is_admin(auth.uid()));
CREATE POLICY "Admins can delete pricing_items" ON public.pricing_items FOR DELETE USING (is_admin(auth.uid()));

-- VEHICLES
DROP POLICY IF EXISTS "Admins can delete vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Admins can insert vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Admins can update vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Anyone can read vehicles" ON public.vehicles;

CREATE POLICY "Anyone can read vehicles" ON public.vehicles FOR SELECT USING (true);
CREATE POLICY "Admins can insert vehicles" ON public.vehicles FOR INSERT WITH CHECK (is_admin(auth.uid()));
CREATE POLICY "Admins can update vehicles" ON public.vehicles FOR UPDATE USING (is_admin(auth.uid()));
CREATE POLICY "Admins can delete vehicles" ON public.vehicles FOR DELETE USING (is_admin(auth.uid()));

-- USER ROLES
DROP POLICY IF EXISTS "Admins can delete user_roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can insert user_roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can view user_roles" ON public.user_roles;

CREATE POLICY "Admins can view user_roles" ON public.user_roles FOR SELECT USING (is_admin(auth.uid()));
CREATE POLICY "Admins can insert user_roles" ON public.user_roles FOR INSERT WITH CHECK (is_admin(auth.uid()));
CREATE POLICY "Admins can delete user_roles" ON public.user_roles FOR DELETE USING (is_admin(auth.uid()));
